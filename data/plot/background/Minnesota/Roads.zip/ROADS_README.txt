
For the newest version of this shapefile please visit: 

https://ottertailcountymn.us/content-page/gis-shapefile-downloads/


Zip file Contents:
README_ROADS.TXT (this file)
Roads.cpg
roads.dbf
roads.prj
roads.shp
roads.shp (XML document)
roads.shx



To make use of this data, specialized software is required. The files included are in ESRI ArcView� shape file format.

 
Projected Coordinate System:	NAD_1983_HARN_Adj_MN_Ottertail_Feet
Projection:	Lambert_Conformal_Conic
False_Easting:	500000.00000000
False_Northing:	100000.00000000
Central_Meridian:	-95.71666667
Standard_Parallel_1:	46.18333333
Standard_Parallel_2:	46.65000000
Latitude_Of_Origin:	46.10638889
Linear Unit: 	Foot_US

Geographic Coordinate System:	GCS_NAD_1983_HARN_Adj_MN_Ottertail
Datum: 	D_NAD_1983_HARN_Adj_MN_Ottertail
Prime Meridian: Greenwich
Angular Unit: 	Degree



DISCLAIMER: The information on www.co.otter-tail.mn.us is made available as a public service. Maps and data are to be used for reference purposes only, and the information on cadastral maps is used to locate, identify and inventory parcels of land in Otter Tail County is for REFERENCE ONLY and is NOT TO BE CONSTRUED OR USED AS A LEGAL DESCRIPTION.
 
Map information is believed to be accurate but accuracy is not guaranteed.

In no event will Otter Tail County be liable for any damages, including loss of data, lost profits, business interruption, loss of business information or other pecuniary loss that may arise from the use of these maps of the information they contain. No responsibility is assumed for damages or other liabilities due to the accuracy, availability, use or misuse of the information herein provided. 

Information on this site is in the public domain and may be copied without permission. Citation of the source is appreciated.
